import asyncio
import math
import re
import time
from typing import Any

from fastapi import HTTPException
from loguru import logger

from app.core.config import settings
from app.core.constants import DEFAULT_CATALOG_LIMIT, ENRICH_HEADROOM, RANDOM_CATALOG_REFRESH_SECONDS
from app.core.security import redact_token
from app.core.settings import UserSettings, resolve_tmdb_api_key
from app.models.library import LibraryCollection
from app.models.profile import TasteProfile
from app.services.catalog_updater import catalog_updater
from app.services.context import UserContext, extract_settings, load_user_context
from app.services.profile.service import ProfileService
from app.services.recommendation.all_based import AllBasedService
from app.services.recommendation.catalog_utils import clean_meta, shuffle_data_if_needed
from app.services.recommendation.creators import CreatorsService
from app.services.recommendation.filtering import filter_watched_by_imdb
from app.services.recommendation.item_based import ItemBasedService
from app.services.recommendation.metadata import RecommendationMetadata
from app.services.recommendation.random_picks import (
    RANDOM_CATALOG_ID,
    RandomService,
    random_catalog_id,
    random_genre_ids,
)
from app.services.recommendation.rewatch import RewatchService
from app.services.recommendation.theme_based import ThemeBasedService
from app.services.recommendation.top_picks import TopPicksService
from app.services.recommendation.utils import content_type_to_mtype
from app.services.redis_service import redis_service
from app.services.tmdb.service import TMDBService, get_tmdb_service
from app.services.token_store import token_store
from app.services.user_cache import user_cache
from app.services.warmup import warmup_service

REFRESH_LOCK_PREFIX = "watchly:refreshlock:"
# Long enough to cover a slow rebuild, short enough that a worker killed mid-refresh
# doesn't keep a row stale for long.
REFRESH_LOCK_TTL_SECONDS = 600


class CatalogService:
    def __init__(self) -> None:
        # Retained so a background refresh isn't garbage collected mid-flight.
        self._refresh_tasks: set[asyncio.Task] = set()

    async def get_catalog(
        self, token: str, content_type: str, catalog_id: str, genre: str | None = None
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        """Get catalog recommendations.

        `genre` is the Discover dropdown pick; only the Random row reads it, since the
        other rows' one option ("All") only exists to keep them off the home board.
        """
        self._validate_inputs(token, content_type, catalog_id)
        if catalog_id == RANDOM_CATALOG_ID:
            catalog_id = random_catalog_id(content_type, genre)

        # Resolve merge aliases up front so credential reads and cache keys all
        # use the surviving account token.
        token = await token_store.resolve_alias(token)

        headers = self._headers()

        logger.debug(f"[{redact_token(token)}] Fetching catalog for {content_type} with id {catalog_id}")

        # Load credentials (needed for cache check + shuffle settings)
        credentials = await token_store.get_user_data(token)
        if not credentials:
            logger.error("No credentials found for token")
            raise HTTPException(
                status_code=401,
                detail="Invalid or expired token. Please reconfigure the addon.",
            )

        # Trigger lazy update if needed. Skipped while a warm-up is running: on a
        # re-configure last_updated carries over from the old record, so this would
        # otherwise fire a full manifest rebuild and Stremio push alongside the warm
        # that is already doing exactly that.
        if settings.AUTO_UPDATE_CATALOGS and not await warmup_service.is_warming(token):
            try:
                await catalog_updater.trigger_update(token, credentials)
            except Exception as e:
                logger.error(f"[{redact_token(token)}] Failed to trigger auto update: {e}")

        # Check cache first — avoids auth/library/profile loading on cache hit
        cached_result = await user_cache.get_catalog(token, content_type, catalog_id)

        if cached_result:
            data, created_at = cached_result
            age = int(time.time()) - created_at
            user_settings = extract_settings(credentials)
            data["metas"] = shuffle_data_if_needed(user_settings, catalog_id, data["metas"])

            if age < self._refresh_after(catalog_id):
                logger.debug(f"[{redact_token(token)}] Using cached catalog for {content_type}/{catalog_id}")
                return data, headers

            # Stale but serveable: hand it back now and rebuild behind the response.
            # Rebuilding inline meant every row on a home screen stalled for a full
            # rebuild once the cache aged out, which is most of the wait users saw.
            logger.info(
                f"[{redact_token(token)}] Catalog stale (age: {age}s) for {content_type}/{catalog_id}, "
                "serving stale and refreshing in the background"
            )
            self._enqueue_refresh(token, content_type, catalog_id)
            return data, headers

        logger.info(
            f"[{redact_token(token)}] Catalog not cached for {content_type}/{catalog_id}, building from scratch"
        )

        # Nothing cached to serve, so this one has to build on the request.
        ctx = await load_user_context(token)
        try:
            return await self._build_catalog(ctx, content_type, catalog_id, headers)
        finally:
            await ctx.close()

    @staticmethod
    def _refresh_after(catalog_id: str) -> int:
        if catalog_id.startswith(RANDOM_CATALOG_ID):
            return RANDOM_CATALOG_REFRESH_SECONDS
        return settings.CATALOG_REFRESH_INTERVAL_SECONDS

    @staticmethod
    def _headers() -> dict[str, Any]:
        """Response headers.

        One max-age for fresh and stale bodies alike. A fresh body used to be
        cacheable 720x longer, which made sense only while ids churned and acted as
        accidental cache-busters; with stable slot ids this header is what tells a
        client a row has changed.
        """
        max_age = settings.CATALOG_CACHE_TTL
        return {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "*",
            "Content-Type": "application/json",
            "Cache-Control": f"private, max-age={max_age},stale-while-revalidate=3600, stale-if-error=1800",
        }

    def _enqueue_refresh(self, token: str, content_type: str, catalog_id: str) -> None:
        task = asyncio.create_task(self._refresh_in_background(token, content_type, catalog_id))
        self._refresh_tasks.add(task)
        task.add_done_callback(self._refresh_tasks.discard)

    async def _refresh_in_background(self, token: str, content_type: str, catalog_id: str) -> None:
        """Rebuild a stale catalog into the cache.

        Locked in Redis rather than in-process because Stremio asks for every
        enabled row at once: without it, one home screen open would kick off a full
        rebuild per row.
        """
        lock_key = f"{REFRESH_LOCK_PREFIX}{token}:{content_type}:{catalog_id}"
        if not await redis_service.set_nx(lock_key, "1", REFRESH_LOCK_TTL_SECONDS):
            logger.debug(f"[{redact_token(token)}] Refresh already running for {content_type}/{catalog_id}")
            return

        try:
            # A scheduled refresh running for this user may replace the library and
            # profiles and drop this row. Rebuilding alongside it would use the old ones
            # and could land afterwards as fresh, so wait, then rebuild only if the row
            # is still stale.
            await catalog_updater.wait_for(token)
            cached = await user_cache.get_catalog(token, content_type, catalog_id)
            if cached and int(time.time()) - cached[1] < self._refresh_after(catalog_id):
                return
            ctx = await load_user_context(token)
            try:
                # Called for the cache write it performs; the response is discarded.
                await self._build_catalog(ctx, content_type, catalog_id, self._headers())
            finally:
                await ctx.close()
            logger.info(f"[{redact_token(token)}] Background refresh done for {content_type}/{catalog_id}")
        except Exception as e:
            logger.warning(f"[{redact_token(token)}] Background refresh failed for {content_type}/{catalog_id}: {e}")
        finally:
            await redis_service.delete(lock_key)

    async def _build_catalog(
        self,
        ctx: UserContext,
        content_type: str,
        catalog_id: str,
        headers: dict[str, Any],
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        """Build fresh catalog content using the loaded user context."""
        try:
            # Resolved only for building. The cache key stays the slot id the client
            # asked for, which is the whole point: it survives a definition change.
            resolved_id = await self._resolve_slot(ctx.token, content_type, catalog_id)
            if resolved_id is None:
                return {"metas": []}, headers

            services = self._initialize_services(ctx.user_settings)
            profile_service: ProfileService = services["profile"]

            # Load profile (cached or build fresh)
            cached_data = await user_cache.get_profile_and_watched_sets(ctx.token, content_type)

            requested_source = ctx.user_settings.watch_history_source if ctx.user_settings else "stremio"
            cached_source = getattr(cached_data[0], "source", "stremio") if cached_data and cached_data[0] else None
            if cached_data and cached_source is not None and cached_source != requested_source:
                logger.info(
                    f"[{redact_token(ctx.token)}] Cached profile source '{cached_source}' "
                    f"!= requested '{requested_source}'; rebuilding."
                )
                cached_data = None

            if cached_data:
                profile, watched_tmdb, watched_imdb = cached_data
                logger.debug(f"[{redact_token(ctx.token)}] Using cached profile for {content_type}")
            else:
                source = ctx.user_settings.watch_history_source if ctx.user_settings else "stremio"
                logger.info(
                    f"[{redact_token(ctx.token)}] Profile not cached for {content_type}, building from {source}"
                )
                profile, watched_tmdb, watched_imdb = await profile_service.build_and_cache_profile(
                    ctx.token,
                    content_type,
                    ctx.library,
                    ctx.bundle,
                    ctx.auth_key,
                    user_settings=ctx.user_settings,
                )

            recommendations = await self._get_recommendations(
                catalog_id=resolved_id,
                content_type=content_type,
                services=services,
                profile=profile,
                watched_tmdb=watched_tmdb,
                watched_imdb=watched_imdb,
                library_items=ctx.library,
                limit=DEFAULT_CATALOG_LIMIT,
                user_settings=ctx.user_settings,
            )

            logger.debug(f"Returning {len(recommendations)} items for {content_type}")

            cleaned = [m for m in (clean_meta(m) for m in recommendations) if m is not None]

            if cleaned:
                await user_cache.set_catalog(
                    ctx.token, content_type, catalog_id, {"metas": cleaned}, settings.CATALOG_STALE_TTL
                )

            return {"metas": shuffle_data_if_needed(ctx.user_settings, catalog_id, cleaned)}, headers

        except Exception as e:
            logger.error(f"[{redact_token(ctx.token)}] Failed to generate catalog: {e}")

            # A stale copy, when one exists, is served before this is ever reached.
            return {"metas": []}, headers

    def _validate_inputs(self, token: str, content_type: str, catalog_id: str) -> None:
        if not token:
            raise HTTPException(
                status_code=400,
                detail="Missing credentials token. Please open Watchly from a configured manifest URL.",
            )

        if content_type not in ["movie", "series"]:
            logger.warning(f"Invalid type: {content_type}")
            raise HTTPException(status_code=400, detail="Invalid type. Use 'movie' or 'series'")

        supported_base = [
            "watchly.rec",
            "watchly.creators",
            "watchly.all.loved",
            "watchly.liked.all",
            "watchly.rewatch",
            RANDOM_CATALOG_ID,
        ]
        # watchly.loved.* / watchly.watched.* kept for legacy stored manifests
        # — installed Stremio clients may still request these IDs after the
        # loved/watched merge until the manifest refreshes.
        supported_prefixes = (
            "watchly.theme.",
            "watchly.item.",
            "watchly.loved.",
            "watchly.watched.",
            f"{RANDOM_CATALOG_ID}.",
        )
        if catalog_id not in supported_base and not any(catalog_id.startswith(p) for p in supported_prefixes):
            logger.warning(f"Invalid id: {catalog_id}")
            raise HTTPException(
                status_code=400,
                detail=(
                    "Invalid id. Supported: 'watchly.rec', 'watchly.creators', "
                    "'watchly.theme.<params>', 'watchly.item.<imdb>', "
                    "'watchly.all.loved', 'watchly.liked.all', 'watchly.rewatch', 'watchly.random'"
                ),
            )

    def _initialize_services(self, user_settings: UserSettings) -> dict[str, Any]:
        tmdb_key = resolve_tmdb_api_key(user_settings)
        language = user_settings.language
        tmdb_service = get_tmdb_service(language=language, api_key=tmdb_key)
        return {
            "tmdb": tmdb_service,
            "profile": ProfileService(language=language, tmdb_api_key=tmdb_key),
            "item": ItemBasedService(tmdb_service, user_settings),
            "theme": ThemeBasedService(tmdb_service, user_settings),
            "top_picks": TopPicksService(tmdb_service, user_settings),
            "creators": CreatorsService(tmdb_service, user_settings),
            "all_based": AllBasedService(tmdb_service, user_settings),
            "rewatch": RewatchService(tmdb_service, user_settings),
            "random": RandomService(tmdb_service, user_settings),
        }

    async def _get_trending_fallback(
        self, tmdb_service: TMDBService, content_type: str, limit: int
    ) -> list[dict[str, Any]]:
        """Trending titles for users without a profile yet."""
        mtype = content_type_to_mtype(content_type)
        pages = range(1, math.ceil(limit * ENRICH_HEADROOM / 20) + 1)
        results = await asyncio.gather(
            *(tmdb_service.get_trending(mtype, "week", page=p) for p in pages), return_exceptions=True
        )
        failed = sum(1 for r in results if isinstance(r, Exception))
        if failed:
            logger.warning(f"Trending fallback: {failed}/{len(results)} {content_type} pages failed")
        return [item for r in results if not isinstance(r, Exception) for item in r.get("results", [])]

    @staticmethod
    async def _resolve_slot(token: str, content_type: str, catalog_id: str) -> str | None:
        """Expand a slot id into the row definition it currently points at.

        Served ids are stable slots (`watchly.theme.2`) so the cache key never moves
        when the row's definition changes. The definitions live in the slot map, and
        expanding one back into the old self-describing form means the existing
        parsers are untouched.

        Ids that aren't slots are returned unchanged: manifests installed before this
        carry self-describing ids and Stremio keeps requesting them until it refreshes.

        None means the slot has no definition — the user reduced their row count and
        the installed client still asks for the dropped slot. Passing the id through
        instead would hand the item engine a bare "3", which it reads as TMDB id 3.
        """
        match = re.match(r"^watchly\.(theme|item)\.(\d+)$", catalog_id)
        if not match:
            return catalog_id

        prefix, slot = match.groups()
        definition = (await user_cache.get_row_map(token, content_type)).get(f"{prefix}.{slot}")
        if not definition:
            logger.warning(f"[{redact_token(token)}] No row definition for {catalog_id} ({content_type})")
            return None

        return f"watchly.{prefix}.{definition}"

    async def _get_recommendations(
        self,
        catalog_id: str,
        content_type: str,
        services: dict[str, Any],
        profile: TasteProfile | None,
        watched_tmdb: set[int],
        watched_imdb: set[str],
        library_items: LibraryCollection,
        limit: int,
        user_settings: UserSettings,
    ) -> list[dict[str, Any]]:
        """Route to the engine for this row, then enrich its ranked candidates.

        Engines only rank. Trimming before enrichment matters: it is a TMDB call or
        two per title, and some engines hand back several hundred candidates.
        """
        tmdb_service: TMDBService = services["tmdb"]

        if any(catalog_id.startswith(p) for p in ("watchly.item.", "watchly.loved.", "watchly.watched.")):
            item_id = re.sub(r"^watchly\.(item|loved|watched)\.", "", catalog_id)
            item_service: ItemBasedService = services["item"]
            candidates = await item_service.get_recommendations_for_item(
                item_id=item_id,
                content_type=content_type,
                watched_tmdb=watched_tmdb,
                limit=limit,
            )

        elif catalog_id.startswith("watchly.theme."):
            theme_service: ThemeBasedService = services["theme"]
            candidates = await theme_service.get_recommendations_for_theme(
                theme_id=catalog_id,
                content_type=content_type,
                profile=profile,
                watched_tmdb=watched_tmdb,
                limit=limit,
            )

        elif catalog_id.startswith(RANDOM_CATALOG_ID):
            random_service: RandomService = services["random"]
            candidates = await random_service.get_random_picks(
                content_type=content_type,
                genre_ids=random_genre_ids(catalog_id, content_type, user_settings),
                watched_tmdb=watched_tmdb,
                limit=limit,
            )

        elif catalog_id == "watchly.creators":
            creators_service: CreatorsService = services["creators"]
            if profile:
                candidates = await creators_service.get_recommendations_from_creators(
                    profile=profile,
                    content_type=content_type,
                    watched_tmdb=watched_tmdb,
                    limit=limit,
                )
            else:
                logger.info(f"No profile for creators, showing trending {content_type}")
                candidates = await self._get_trending_fallback(tmdb_service, content_type, limit)

        elif catalog_id == "watchly.rec":
            if profile:
                top_picks_service: TopPicksService = services["top_picks"]
                candidates = await top_picks_service.get_top_picks(
                    profile=profile,
                    content_type=content_type,
                    library_items=library_items,
                    watched_tmdb=watched_tmdb,
                    limit=limit,
                )
            else:
                logger.info(f"No profile for top picks, showing trending {content_type}")
                candidates = await self._get_trending_fallback(tmdb_service, content_type, limit)

        elif catalog_id in ("watchly.all.loved", "watchly.liked.all"):
            item_type = "loved" if catalog_id == "watchly.all.loved" else "liked"
            all_based_service: AllBasedService = services["all_based"]
            candidates = await all_based_service.get_recommendations_from_all_items(
                library_items=library_items,
                content_type=content_type,
                watched_tmdb=watched_tmdb,
                limit=limit,
                item_type=item_type,
                profile=profile,
            )

        elif catalog_id == "watchly.rewatch":
            rewatch_service: RewatchService = services["rewatch"]
            candidates = await rewatch_service.get_rewatch_picks(
                library_items=library_items,
                content_type=content_type,
                profile=profile,
                limit=limit,
            )

        else:
            logger.warning(f"Unknown catalog ID: {catalog_id}")
            return []

        # Already-watched titles are the whole point of the rewatch row.
        if catalog_id != "watchly.rewatch":
            # Simkl candidates carry their IMDb id, so watched ones can go before
            # paying for their enrichment.
            candidates = [c for c in candidates if c.get("_imdb_id") not in watched_imdb]

        candidates = candidates[: int(limit * ENRICH_HEADROOM)]
        metas = await RecommendationMetadata.fetch_batch(tmdb_service, candidates, content_type, user_settings)
        if catalog_id != "watchly.rewatch":
            metas = filter_watched_by_imdb(metas, watched_imdb)

        logger.debug(f"{catalog_id} ({content_type}): {len(metas[:limit])} items from {len(candidates)} candidates")
        return metas[:limit]


catalog_service = CatalogService()
