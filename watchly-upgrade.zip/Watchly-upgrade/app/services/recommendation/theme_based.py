import asyncio
import math
from typing import Any

from loguru import logger

from app.core.constants import ENRICH_HEADROOM
from app.models.profile import TasteProfile
from app.services.profile.constants import (
    RUNTIME_BUCKET_MEDIUM_MAX_MOVIE,
    RUNTIME_BUCKET_MEDIUM_MAX_SERIES,
    RUNTIME_BUCKET_SHORT_MAX_MOVIE,
    RUNTIME_BUCKET_SHORT_MAX_SERIES,
)
from app.services.profile.scorer import ProfileScorer
from app.services.recommendation.filtering import RecommendationFiltering, apply_discover_filters
from app.services.recommendation.scoring import RecommendationScoring
from app.services.recommendation.utils import content_type_to_mtype
from app.services.tmdb.service import TMDBService


class ThemeBasedService:
    """
    Handles theme-based recommendations using role-based axis recipes.

    Strategy:
    1. Parse role-based theme ID (a: anchor, f: flavor, b: fallback)
    2. Primary discovery using Anchors
    3. Weighted scoring: anchor (1.0) + flavor (0.7) + fallback (0.3)
    4. Profile-aware ranking
    5. Expansion logic if results are sparse
    """

    def __init__(self, tmdb_service: Any, user_settings: Any = None):
        self.tmdb_service: TMDBService = tmdb_service
        self.user_settings = user_settings
        self.scorer = ProfileScorer()

    async def get_recommendations_for_theme(
        self,
        theme_id: str,
        content_type: str,
        profile: TasteProfile | None = None,
        watched_tmdb: set[int] | None = None,
        limit: int = 20,
    ) -> list[dict[str, Any]]:
        """Get recommendations for a role-based theme."""
        watched_tmdb = watched_tmdb or set()

        # 1. Parse roles and values
        anchors, flavors, fallbacks = self._parse_theme_id(theme_id)

        # 2. Prepare common excluded genres
        excluded_ids = RecommendationFiltering.get_excluded_genre_ids(self.user_settings, content_type)

        # 3. Extract mandatory filters (country/era from ANY role)
        all_constraints = {**anchors, **flavors, **fallbacks}
        mandatory_filters = {}
        if "country" in all_constraints:
            mandatory_filters["country"] = all_constraints["country"]
        if "era" in all_constraints:
            mandatory_filters["era"] = all_constraints["era"]

        logger.info(f"Theme discovery for {theme_id}: anchors={anchors}, flavors={flavors}, fallbacks={fallbacks}")

        # ====================
        # PHASE 1: Combined Fetch (ALL constraints)
        # ====================
        fetch_tasks = []
        if all_constraints:
            combined_params = self._axes_to_params(all_constraints, content_type)
            if excluded_ids:
                with_ids = {int(g) for g in combined_params.get("with_genres", "").split("|") if g}
                without = [g for g in excluded_ids if g not in with_ids]
                if without:
                    combined_params["without_genres"] = "|".join(str(g) for g in without)
            fetch_tasks.append(
                self._fetch_discover_candidates(
                    content_type, combined_params, max_pages=math.ceil(limit * ENRICH_HEADROOM / 20)
                )
            )

        # Execute Phase 1
        results = await asyncio.gather(*fetch_tasks, return_exceptions=True)
        candidates = []
        for res in results:
            if isinstance(res, Exception):
                logger.debug(f"Error fetching combined: {res}")
                continue
            if isinstance(res, list):
                for item in res:
                    item["_discovery_tier"] = "combined"
                candidates.extend(res)

        logger.info(f"Phase 1 (combined): {len(candidates)} candidates")

        # ====================
        # PHASE 2: Individual Axes (if sparse)
        # ====================
        if len(candidates) < limit * 2:
            fetch_tasks = []

            # For EACH axis in anchors, flavors, AND fallbacks
            for axis_name, axis_value in all_constraints.items():
                # Build params for this single axis
                params = self._axes_to_params({axis_name: axis_value}, content_type)

                # ALWAYS add mandatory filters (country/era) if they exist and are not the current axis
                for filter_name, filter_value in mandatory_filters.items():
                    if filter_name != axis_name:  # Don't duplicate
                        filter_params = self._axes_to_params({filter_name: filter_value}, content_type)
                        params.update(filter_params)

                # Apply excluded genres
                if excluded_ids:
                    with_ids = {int(g) for g in params.get("with_genres", "").split("|") if g}
                    without = [g for g in excluded_ids if g not in with_ids]
                    if without:
                        params["without_genres"] = "|".join(str(g) for g in without)

                fetch_tasks.append(self._fetch_discover_candidates(content_type, params, max_pages=5))

            # Execute Phase 2
            results = await asyncio.gather(*fetch_tasks, return_exceptions=True)
            for res in results:
                if isinstance(res, Exception):
                    logger.debug(f"Error fetching individual: {res}")
                    continue
                if isinstance(res, list):
                    for item in res:
                        item["_discovery_tier"] = "individual"
                    candidates.extend(res)

            logger.info(f"Phase 2 (individual): Total {len(candidates)} candidates")

        # 4. Expansion Logic if still sparse
        if len(candidates) < limit and anchors:
            # Expansion strategy: Relax constraints on the primary anchor
            primary_axis = dict([next(iter(anchors.items()))])
            base_p = self._axes_to_params(primary_axis, content_type)
            expanded = await self._expand_search(content_type, base_p, anchors, flavors)
            for item in expanded:
                item["_discovery_tier"] = "expanded"
            candidates.extend(expanded)

        # 5. Weighted Scoring
        scored = []
        mtype = content_type_to_mtype(content_type)

        for item in candidates:
            # Theme Match Score
            theme_match = self._calculate_theme_score(item, anchors, flavors, fallbacks)

            # Profile & Quality Score
            if profile:
                base_score = RecommendationScoring.calculate_final_score(
                    item=item,
                    profile=profile,
                    scorer=self.scorer,
                    mtype=mtype,
                )
            else:
                base_score = RecommendationScoring.normalize(item.get("vote_average", 0))

            # Combine: theme match is the primary sorter for catalog rows
            final_score = (theme_match * 0.7) + (base_score * 0.3)

            # Apply tier multiplier
            tier = item.get("_discovery_tier", "individual")
            if tier == "combined":
                final_score *= 2.0  # Boost combined matches to appear first

            scored.append((final_score, item))

        # 6. Rank and Enrich
        scored.sort(key=lambda x: x[0], reverse=True)
        unique_results = []
        seen = set()
        for _, item in scored:
            if item["id"] not in seen and item["id"] not in watched_tmdb:
                unique_results.append(item)
                seen.add(item["id"])
            if len(unique_results) >= limit * ENRICH_HEADROOM:
                break

        return unique_results

    def _parse_theme_id(self, theme_id: str) -> tuple[dict, dict, dict]:
        """Parse role-based ID: watchly.theme.a:g123.f:k456.b:y1990"""
        parts = theme_id.replace("watchly.theme.", "").split(".")
        anchors, flavors, fallbacks = {}, {}, {}

        roles = {"a": anchors, "f": flavors, "b": fallbacks}

        for idx, part in enumerate(parts):
            if ":" not in part:
                # old format
                if idx == 0:
                    target = anchors
                elif idx == 1:
                    target = flavors
                elif idx == 2:
                    target = fallbacks
                else:
                    continue
                val = part
            else:
                role, val = part.split(":", 1)
                target = roles.get(role)

            if target is None:
                continue

            if val.startswith("g"):
                target["genre"] = val[1:]
            elif val.startswith("k"):
                target["keyword"] = val[1:]
            elif val.startswith("ct"):
                target["country"] = val[2:]
            elif val.startswith("y"):
                target["era"] = val[1:]
            elif val.startswith("r"):
                target["runtime"] = val[1:]
            elif val.startswith("cr"):
                target["creator"] = val[2:]

        return anchors, flavors, fallbacks

    def _axes_to_params(self, axes: dict, content_type: str) -> dict:
        """Convert axes to TMDB discover params."""
        params = {}
        if "genre" in axes:
            params["with_genres"] = axes["genre"].replace("-", "|")
        if "keyword" in axes:
            params["with_keywords"] = axes["keyword"].replace("-", "|")
        if "country" in axes:
            params["with_origin_country"] = axes["country"]
        if "era" in axes:
            try:
                # Value can be single year or range
                val = axes["era"]
                if "-" in val:
                    start_year = int(val.split("-")[0])
                    end_year = int(val.split("-")[1])
                else:
                    start_year = int(val)
                    end_year = start_year + 9

                prefix = "first_air_date" if content_type in ("tv", "series") else "primary_release_date"
                params[f"{prefix}.gte"] = f"{start_year}-01-01"
                params[f"{prefix}.lte"] = f"{end_year}-12-31"
            except Exception:
                logger.error("Failed to parse era axis: {}", axes["era"])
                pass
        if "runtime" in axes:
            bucket = axes["runtime"]
            is_movie = content_type == "movie"
            s_max = RUNTIME_BUCKET_SHORT_MAX_MOVIE if is_movie else RUNTIME_BUCKET_SHORT_MAX_SERIES
            m_max = RUNTIME_BUCKET_MEDIUM_MAX_MOVIE if is_movie else RUNTIME_BUCKET_MEDIUM_MAX_SERIES
            if bucket == "short":
                params["with_runtime.lte"] = s_max
            elif bucket == "medium":
                params["with_runtime.gte"] = s_max
                params["with_runtime.lte"] = m_max
            elif bucket == "long":
                params["with_runtime.gte"] = m_max
        return params

    def _calculate_theme_score(self, item: dict, anchors: dict, flavors: dict, fallbacks: dict) -> float:
        """Calculate weighted score based on axis matches."""
        score = 0.0

        def check_match(axis_name, value):
            if axis_name == "genre":
                item_genres = [str(gid) for gid in item.get("genre_ids", [])]
                target_genres = str(value).split("-")
                return any(tg in item_genres for tg in target_genres)
            if axis_name == "keyword":
                return True  # Optimistic match for discovery items
            if axis_name == "country":
                item_countries = item.get("origin_country", [])
                return value in item_countries
            if axis_name == "era":
                rel = item.get("release_date") or item.get("first_air_date")
                if rel:
                    try:
                        y = int(rel[:4])
                        if "-" in value:
                            start, end = map(int, value.split("-"))
                        else:
                            start = int(value)
                            end = start + 9
                        return start <= y <= end
                    except Exception:
                        logger.error("Failed to parse era axis: {}", value)
                        pass
            if axis_name == "runtime":
                # Runtimes are hard to match exactly from discover results without metadata enrichment
                return True
            return False

        total_anchors = len(anchors)
        matched_anchors = 0
        for name, val in anchors.items():
            if check_match(name, val):
                score += 1.0
                matched_anchors += 1

        # Perfect Match Bonus: Significant boost for items satisfying all anchors
        if total_anchors > 1 and matched_anchors == total_anchors:
            score += 2.0
        elif total_anchors > 0:
            # Proportion boost to differentiate partial matches
            score += (matched_anchors / total_anchors) * 0.5

        for name, val in flavors.items():
            if check_match(name, val):
                score += 0.7
        for name, val in fallbacks.items():
            if check_match(name, val):
                score += 0.3

        return score

    async def _expand_search(self, content_type: str, params: dict, anchors: dict, flavors: dict) -> list[dict]:
        """Expansion logic if results are sparse."""
        # 1. Relax Keyword: Remove keyword constraint
        if "with_keywords" in params:
            new_params = params.copy()
            del new_params["with_keywords"]
            return await self._fetch_discover_candidates(content_type, new_params, max_pages=5)

        return []

    def _calculate_pages_to_fetch(self, num_excluded_genres: int) -> list[int]:
        """
        Calculate how many pages to fetch based on excluded genres.

        Args:
            num_excluded_genres: Number of excluded genres

        Returns:
            List of page numbers to fetch
        """
        if num_excluded_genres > 10:
            return list(range(1, 11))  # 10 pages
        elif num_excluded_genres > 5:
            return list(range(1, 6))  # 5 pages
        else:
            return [1, 2, 3]  # 3 pages

    async def _fetch_discover_candidates(
        self, content_type: str, params: dict[str, Any], max_pages: int
    ) -> list[dict[str, Any]]:
        """Pages 1..max_pages of a discover query, stopping at the query's last page.

        Page 1 goes first because it carries total_pages: narrow themes often have
        only a page or two, and asking past the end costs a request each for nothing.
        """
        params = apply_discover_filters(params, self.user_settings)

        try:
            first = await self.tmdb_service.get_discover(content_type, page=1, **params)
        except Exception as e:
            logger.debug(f"Error fetching discover: {e}")
            return []

        candidates = list(first.get("results", []))
        last_page = min(first.get("total_pages", 1), max_pages)
        tasks = [self.tmdb_service.get_discover(content_type, page=p, **params) for p in range(2, last_page + 1)]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        for res in results:
            if isinstance(res, Exception):
                logger.debug(f"Error fetching discover: {res}")
                continue
            candidates.extend(res.get("results", []))

        return candidates
